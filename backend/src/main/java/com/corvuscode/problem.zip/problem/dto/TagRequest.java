package com.corvuscode.problem.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TagRequest {

    @NotBlank(message = "Tag name is required.")
    @Size(max = 50, message = "Tag name must not exceed 50 characters.")
    private String name;
}